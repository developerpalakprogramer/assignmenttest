<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class TodoController extends CI_Controller {
	function __construct() { 
        parent::__construct(); 
        $this->load->library('form_validation'); 
        $this->load->model('TaskModel'); 
        // User login status 
        $this->isUserLoggedIn = $this->session->userdata('isUserLoggedIn');
       
        if($this->isUserLoggedIn !=1){
        	redirect('login');
        }
    } 
     
    public function index(){ 
       		$data['lists'] =$this->TaskModel->getTasks(); 	 
            $this->load->view('layouts/header', $data); 
	        $this->load->view('todo/list', $data); 
	        $this->load->view('layouts/footer'); 
        
    }
    public function create(){ 
        $data = $taskdata = array(); 
          
        if($this->input->post('addTask')){ 
            $this->form_validation->set_rules('title', 'Title', 'required'); 
            $this->form_validation->set_rules('status', 'Status', 'required'); 
            $this->form_validation->set_rules('description', 'Description', 'required'); 
           
            $taskdata = array( 
                'title' => strip_tags($this->input->post('title')),
                'status' => ($this->input->post('status') =='uncompleted')?'0':'1', 
                'description' => strip_tags($this->input->post('description')),
            ); 
 
            if($this->form_validation->run() == true){ 
                $insert = $this->TaskModel->insert($taskdata); 
                if($insert){ 
                    $this->session->set_userdata('success_msg', 'Task has been created successfully'); 
                    redirect('todo/list'); 
                }else{ 
                    $data['error_msg'] = 'Some problems occured, please try again.'; 
                } 
            }else{ 
                $data['error_msg'] = 'Please fill all the mandatory fields.'; 
            } 
        } 
          
        $data['taskdata'] = $taskdata; 
        $this->load->view('layouts/header', $data); 
        $this->load->view('todo/add', $data); 
        $this->load->view('layouts/footer'); 
    } 

    public function update($id)
    {
    	$data=$updatetask=array();
    	 $con = array( 
                    'returnType' => 'single', 
                    'conditions' => array( 
                        'id'=> $id 
                    ) 
                ); 
    	 if($this->input->post('updateTask')){ 
    	 	$this->form_validation->set_rules('title', 'Title', 'required'); 
            $this->form_validation->set_rules('status', 'Status', 'required'); 
            $this->form_validation->set_rules('description', 'Description', 'required'); 
    	 }
    	
    	 //echo $this->input->post('status') ;die;
    	 $taskdata = array( 
                'title' => strip_tags($this->input->post('title')),
                'status' => ($this->input->post('status') =='uncompleted')?'0':'1', 
                'description' => strip_tags($this->input->post('description')),
                'modified'=>date("Y-m-d H:i:s")
            );
         	if($this->form_validation->run() == true){ 
                $resp = $this->TaskModel->update($taskdata,$id); 
                if($resp){ 
                    $this->session->set_userdata('success_msg', 'Task has been Updated successfully'); 
                    redirect('todo/list'); 
                }else{ 
                    $data['error_msg'] = 'Some problems occured, please try again.'; 
                } 
            }       
    	$data['list'] =$this->TaskModel->getRows($con); 
    	$this->load->view('layouts/header', $data); 
        $this->load->view('todo/edit', $data); 
        $this->load->view('layouts/footer'); 
    }
     public function delete($id){ 
       		$res =$this->TaskModel->getTaskById($id);
       		if($res){
       			$this->session->set_userdata('success_msg', 'Task has been Deleted successfully'); 
       		}else{
       			$this->session->set_userdata('error_msg', 'Some problems occured, please try again.'); 
       		}
       			 
            redirect('todo/list');
        
    }
}