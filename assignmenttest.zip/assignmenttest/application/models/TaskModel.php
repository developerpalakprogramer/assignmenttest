<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
 
class TaskModel extends CI_Model{ 
    function __construct() { 
        $this->table = 'tasks'; 
    } 
     
    public function getRows($params = array()){ 
        $this->db->select('*'); 
        $this->db->from($this->table); 
         
        if(array_key_exists("conditions", $params)){ 
            foreach($params['conditions'] as $key => $val){ 
                $this->db->where($key, $val); 
            } 
        } 
         
        if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){ 
            $result = $this->db->count_all_results(); 
        }else{ 
            if(array_key_exists("id", $params) || $params['returnType'] == 'single'){ 
                if(!empty($params['id'])){ 
                    $this->db->where('id', $params['id']); 
                } 
                $query = $this->db->get(); 
                $result = $query->row_array(); 
            }else{ 
                $this->db->order_by('id', 'desc'); 
                if(array_key_exists("start",$params) && array_key_exists("limit",$params)){ 
                    $this->db->limit($params['limit'],$params['start']); 
                }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){ 
                    $this->db->limit($params['limit']); 
                } 
                 
                $query = $this->db->get(); 
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE; 
            } 
        } 
          
        return $result; 
    } 

    public function update($taskdata,$id)
    {
        $resp = $this->db->where(['id'=>$id])->update($this->table,$taskdata);
        if($resp){
            return TRUE;
        }else{
            return FALSE;
        }
    }

     public function getTasks()
    {
        $resp = $this->db->select('*')->from($this->table)->get()->result_array();

        if(!empty($resp)){
            return $resp;
        }else{
            return FALSE;
        }
    }
     
  
    public function insert($data = array()) { 
        if(!empty($data)){ 
            // Add created and modified date if not included 
            if(!array_key_exists("created", $data)){ 
                $data['created'] = date("Y-m-d H:i:s"); 
            } 
            if(!array_key_exists("modified", $data)){ 
                $data['modified'] = date("Y-m-d H:i:s"); 
            }  
            $insert = $this->db->insert($this->table, $data); 
             
            // Return the status 
            return $insert?$this->db->insert_id():false; 
        } 
        return false; 
    } 
    public function getTaskById($id)
    {
        $resp = $this->db->where(['id'=>$id])->delete($this->table);
        if(!empty($resp)){
            return TRUE;
        }else{
            return FALSE;
        }
    }
}