<div class="container mt-5">
    <h2>Create a New Account</h2>
	
    <!-- Status message -->
    <?php  
        if(!empty($success_msg)){?> 
            <div class="alert alert-success">
                <strong><?php echo $success_msg;?></strong>
            </div>
            
        <?php } elseif(!empty($error_msg)){ ?>
              <div class="alert alert-danger">
                <strong><?php echo $error_msg;?></strong>
            </div>
        <?php } 
    ?>


    <form action="" method="post">
        <div class="form-group">
      <label for="email">User Name:</label>
      <input type="text" class="form-control" id="user_name" placeholder="User Name" name="user_name">
       <?php echo form_error('user_name','<p style="color:red">','</p>'); ?>
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
       <?php echo form_error('email','<p style="color:red">','</p>'); ?>
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password">
       <?php echo form_error('password','<p style="color:red">','</p>'); ?>
    </div>
    <div class="form-group">
      <label for="pwd">Confirm Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter Confirm password" name="conf_password">
       <?php echo form_error('conf_password','<p style="color:red">','</p>'); ?>
    </div>
    <input type="submit" class="btn btn-primary" name="signupSubmit" value="Create Account">
  </form>
  <p>Already have an account? <a href="<?php echo base_url('login'); ?>">Login here</a></p>
</div>