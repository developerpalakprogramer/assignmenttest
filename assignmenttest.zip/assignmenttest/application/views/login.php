<div class="container mt-5">
    
    <h2>Login to Your Account</h2>
	
    <!-- Status message -->
    <?php  
        if(!empty($success_msg)){?> 
            <div class="alert alert-success">
                <strong><?php echo $success_msg;?></strong>
            </div>
            
        <?php } elseif(!empty($error_msg)){ ?>
              <div class="alert alert-danger">
                <strong><?php echo $error_msg;?></strong>
            </div>
        <?php } 
    ?>
	
    <!-- Login form -->
  <form action="" method="post">
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
         <?php echo form_error('email','<p style="color:red">','</p>'); ?>
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password">
       <?php echo form_error('password','<p style="color:red">','</p>'); ?>
    </div>
    <input type="submit" class="btn btn-primary" name="loginSubmit" value="Login">
  </form>
  <p>Don't have an account? <a href="<?php echo base_url('register'); ?>">Register</a></p>
</div>