
<div class="container mt-5">
     <a href="<?php echo base_url('todo/list'); ?>" class="btn btn-primary btn-md mb-5" style="float: right;">Task List</a>
    <h2>Add Task</h2>

	
    <!-- Status message -->
    <?php  
        if(!empty($success_msg)){?> 
            <div class="alert alert-success">
                <strong><?php echo $success_msg;?></strong>
            </div>
            
        <?php } elseif(!empty($error_msg)){ ?>
              <div class="alert alert-danger">
                <strong><?php echo $error_msg;?></strong>
            </div>
        <?php } 
    ?>
	
    <!-- Login form -->
  <form action="" method="post">
    <div class="form-group">
      <label for="title">Title:</label>
      <input type="text" class="form-control" id="title" placeholder="Enter Title" name="title">
       <?php echo form_error('title','<p style="color:red">','</p>'); ?>
    </div>
    <div class="form-group">
    	 <label for="Description">Description:</label>
      <textarea class="form-control" rows="5" id="description" name="description" placeholder="Enter Description" ></textarea>
       <?php echo form_error('description','<p style="color:red">','</p>'); ?>
    </div>
    <div class="form-group">
      <label for="Description">Status:</label>
      <select class="form-control" id="status" name="status">
	    <option value="uncompleted">Uncompleted</option>
	    <option value="completed">Completed</option>
  </select>
       <?php echo form_error('status','<p style="color:red">','</p>'); ?>
    </div>
    <input type="submit" class="btn btn-primary" name="addTask" value="Create">
  </form>
  
</div>