<div class="container mt-5">
	<a href="<?php echo base_url('todo/create'); ?>" class="btn btn-primary btn-md mb-5" style="float: right;">Create</a>
	&nbsp;<a href="<?php echo base_url('logout'); ?>" class="btn btn-success btn-md mb-5" style="float: right;">logout</a>
	<h2>Task List</h2>

	
    <!-- Status message -->
    <?php  
        if(!empty($success_msg)){?> 
            <div class="alert alert-success">
                <strong><?php echo $success_msg;?></strong>
            </div>
            
        <?php } elseif(!empty($error_msg)){ ?>
              <div class="alert alert-danger">
                <strong><?php echo $error_msg;?></strong>
            </div>
        <?php } 
    ?>

    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
            	<th>S. No.</th>
                <th>Title</th>
                <th>Description</th>
                <th>Status</th>
                <th>Created at</th>
                <th>Updated at</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        	<?php 
        	 if(isset($lists) && count($lists)>0){
        	 	$sn=1;
        	 	foreach ($lists as $value) {
        	?>
            <tr>
            	<td><?php echo $sn;?></td>
                <td><?php echo $value['title']?></td>
                <td><?php echo  substr($value['description'], 0, 50)?>...</td>
                <td><?php echo ($value['status']=='0')?'Uncompleted':'Completed';?></td>
                <td><?php echo $value['created']?></td>
                <td><?php echo $value['modified']?></td>
                <td><a href="<?php echo base_url('todo/edit/'.$value['id']);?>" class="btn btn-primary btn-md">Edit</a>&nbsp;<a href="<?php echo base_url('todo/delete/'.$value['id']);?>" class="btn btn-danger btn-md">Delete</a></td>
            </tr>
            <?php 
            	$sn++;
        }} else { ?>
            	<tr><td colspan="6">No Data</td></tr>
            <?php }?>
    	</tbody>
    </table>	        
</div>

<script>
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>	