Login
url-http://localhost/assignmenttest/index.php/login

Demo credentail

email-test2@gmail.com
password-123

database name -assignmenttest
sql file - assignmenttest.sql